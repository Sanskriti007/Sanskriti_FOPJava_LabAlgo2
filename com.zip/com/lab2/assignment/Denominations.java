package com.lab2.assignment;

import java.util.Arrays;
import java.util.Collections;
import java.util.Scanner;

public class Denominations {

	public static void main(String[] args) {
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter the size of currency denomination:");
		int size=sc.nextInt();
		System.out.println("Enter the denomination:");
		Integer[] denom = new Integer[size];
		for(int i=0;i<size;i++) {
			denom[i]=sc.nextInt();
			
		}
		
		System.out.println("Enter the amount");
		int amt = sc.nextInt();
		Arrays.sort(denom,Collections.reverseOrder());
		int j=0;
		int[] CurrCount = new int[size];
		while(amt>0) {
			CurrCount[j]=amt/denom[j];
			amt-=(denom[j]*CurrCount[j]);
			j++;
		}
		for(int k = 0;k<size;k++) {
			System.out.println(denom[k] + " : "+CurrCount[k]);
		}
	}

}
